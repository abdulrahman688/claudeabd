"""Core module for configuration and shared utilities."""

from .config import settings

__all__ = ["settings"]

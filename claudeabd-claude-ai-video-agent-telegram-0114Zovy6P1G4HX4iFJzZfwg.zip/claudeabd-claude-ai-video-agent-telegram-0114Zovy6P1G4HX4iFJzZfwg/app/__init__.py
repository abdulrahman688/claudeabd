"""
Pro-Small-Business AI Video Agent
Empowering small local merchants with high-end marketing tools
"""

__version__ = "1.0.0"
__author__ = "AI Video Agent Team"
